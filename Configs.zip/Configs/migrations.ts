import store from './configureStore';
import config from './config.json';
import { find } from 'lodash';

// config.json will be updated during the CI run on pull request and added to the repo
export const PERSIST_VERSION = Number(config.version);

// migration key here should be same as version number in persist config
export const getPersistMigrations = () => {
  return {
    [PERSIST_VERSION]: () => {
      const sessionStorageKeys = Object.keys(window.sessionStorage);

      const foundKey = find(sessionStorageKeys, (key) => key.includes('storage-key'));

      if (foundKey) {
        window.sessionStorage.removeItem(foundKey);
      }

      return store.getState();
    },
  };
};
