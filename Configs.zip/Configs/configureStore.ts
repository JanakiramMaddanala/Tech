import { routerMiddleware } from 'connected-react-router';
import { createBrowserHistory } from 'history';
import { applyMiddleware, createStore } from 'redux';
import createSagaMiddleware from 'redux-saga';
import { composeWithDevTools } from 'redux-devtools-extension';
import { persistStore, persistReducer, createMigrate } from 'redux-persist';
import sessionStorage from 'redux-persist/lib/storage/session';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';
import { rootReducer } from './rootReducer';
import rootSaga from './rootSaga';
import { getPersistMigrations, PERSIST_VERSION } from './migrations';
import { forEach } from 'lodash';
import { transformA, transformB } from './transforms';

const id = '';

cleanupPersistStorage();

function cleanupPersistStorage() {
  const sessionStorageKeys = Object.keys(window.sessionStorage);

  forEach(sessionStorageKeys, (key) => {
    const hasPersistKey = key.includes('persist:app') && !key.includes(id);

    if (hasPersistKey) {
      window.sessionStorage.removeItem(key);
    }
  });
}

export const history = createBrowserHistory();

const DEBUG = process.env.NODE_ENV !== 'production';

const persistConfig: any = {
  key: `app-${id}`,
  storage: sessionStorage,
  stateReconciler: autoMergeLevel2,
  debug: DEBUG,
  version: PERSIST_VERSION,
  blacklist: [
    'app',
    'router',
    'theme',
    'state_field_name_1',
    'state_field_name_2',
    'state_field_name_3',
  ],
  transforms: [transformA, transformB],
  migrate: createMigrate(getPersistMigrations(), { debug: DEBUG }),
};

const persistedReducer = persistReducer(persistConfig, rootReducer(history));

const sagaMiddleware = createSagaMiddleware();

const middlewares = [sagaMiddleware, routerMiddleware(history)];

const storeEnhancer = composeWithDevTools(applyMiddleware(...middlewares));

const store = createStore(persistedReducer, storeEnhancer);

sagaMiddleware.run(rootSaga);

export const persistor = persistStore(store);

export default store;
