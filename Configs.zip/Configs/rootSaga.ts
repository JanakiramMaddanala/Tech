import { all, takeLatest } from 'redux-saga/effects';

function* workerSagaA() { }

function* workerSagaB() { }

function* watchSagaA() {
    yield takeLatest('ACTION_NAME_A', workerSagaA);
}

function* watchSagaB() {
    yield takeLatest('ACTION_NAME_B', workerSagaB);
}

export default function* rootSaga() {
  yield all([
    watchSagaA(),
    watchSagaB()
  ]);
}


