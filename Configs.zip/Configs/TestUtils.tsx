import React from 'react';
import { render } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import { Provider } from 'react-redux';
import { Router } from 'react-router-dom';
import { Route } from 'react-router';
import { I18nextProvider } from 'react-i18next';
import i18nTest from '../../tests/js/i18nTest';


export function renderConnectedComponentWithRouter(
  component: any,
  { path = '/', route = '/', history = createMemoryHistory({ initialEntries: [route] }) }: any,
  store: any,
  props: any = {}
) {
  const Component = component;

  const content = (reduxStore: any) => {
    return (
      <Provider store={reduxStore}>
        <I18nextProvider i18n={i18nTest}>
          <Router history={history}>
            <Route path={path}>
              <Component {...props} />
            </Route>
          </Router>
        </I18nextProvider>
      </Provider>
    );
  };

  return {
    ...render(content(store)),
    content,
  };
}

export function renderWithRedux(component: any, store: any, props: any = {}) {
  const Component = component;

  const content = (reduxStore: any) => {
    return (
      <Provider store={reduxStore}>
        <I18nextProvider i18n={i18nTest}>
          <Component {...props} />
        </I18nextProvider>
      </Provider>
    );
  };

  return {
    ...render(content(store)),
    content,
    component,
  };
}

export function renderComponentWithRedux(component: any, store: any) {
  const content = (reduxStore: any) => {
    return (
      <Provider store={reduxStore}>
        <I18nextProvider i18n={i18nTest}>{component}</I18nextProvider>
      </Provider>
    );
  };

  return {
    ...render(content(store)),
    content,
  };
}
