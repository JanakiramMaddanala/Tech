import '@testing-library/jest-dom';
import './tests/js/i18nTest';

jest.mock('../../frontend/src/i18n', () => {
  const i18nTest = jest.requireActual('./tests/js/i18nTest');

  return i18nTest;
});

global.localStorage = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};

window.matchMedia =
  window.matchMedia ||
  function () {
    return {
      matches: false,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  };

window.ResizeObserver =
  window.ResizeObserver ||
  function () {
    return {
      observe: jest.fn(),
      unobserve: jest.fn(),
      disconnect: jest.fn(),
    };
  };
