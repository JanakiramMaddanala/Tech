import React, { Suspense } from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { CookiesProvider } from 'react-cookie';
import './i18n';
import { App } from './app';
import store, { persistor } from './configureStore';
import './index.css';
import { PersistGate } from 'redux-persist/integration/react';
import { LinearProgress } from '@material-ui/core';
import { ErrorBoundary } from './app/components/ErrorBoundary';

ReactDOM.render(
  <CookiesProvider>
    <Provider store={store}>
      <PersistGate loading={<LinearProgress />} persistor={persistor}>
        <Suspense fallback={<LinearProgress />}>
          <ErrorBoundary>
            <App />
          </ErrorBoundary>
        </Suspense>
      </PersistGate>
    </Provider>
  </CookiesProvider>,
  document.getElementById('root')
);
