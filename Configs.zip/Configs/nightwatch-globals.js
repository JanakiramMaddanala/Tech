const allureReporter = require('nightwatch-allure');
var fsExtra = require('fs-extra');

module.exports = {
  reporter: (results, done) => {
    fsExtra.emptyDir('./allure-results');
    const reporter = new allureReporter.NightwatchAllureReporter({});
    reporter.write(results, done);
  },
};
