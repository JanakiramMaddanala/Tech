console.log([...[..."..."]].length);

let personInfo = [1, "Foo", new Date("2020-01-01")];

function displayPersonInfo(id, name, dob) {
  console.log(id);
  console.log(name);
  console.log(dob);
}

displayPersonInfo(...personInfo);
