function getValue() {
  try {
    return 2;
  } finally {
    return 4;
  }
}

console.log(getValue());
