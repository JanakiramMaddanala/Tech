// String Concatenation
console.log("b" + "a" + +(+"l") + "a");

console.log("b" + "a" + 1);

console.log("1" - "b" + "2");
console.log("2" - "3" + "a");
console.log(false + "2" - "3" + true);
console.log("2" - "3" + false + true);

let a = 0;
console.log(a ? "Valid" : "Invalid");

console.log("2" - "3" + false + true);
