const fruits = [
  [["apple"]],
  "mango",
  ["kiwi"],
  [[[["orange"]]], ["guava"]],
  "watermelon",
];

const fruits = ["apple", "mango", "kiwi", "orange", "guava", "watermelon"];

console.log(fruits.flat(Number.POSITIVE_INFINITY));
