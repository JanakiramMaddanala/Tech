const numbers = [1, 11, 5, 10];

console.log(numbers.sort());
