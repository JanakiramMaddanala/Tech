function* getStates() {
  yield "Andhra Pradesh";
  yield "Telangana";
  yield "Karnataka";
  yield "Uttar Pradesh";
}

const stateGenerator = getStates();

let done, value;
do {
  ( { done, value }) = stateGenerator.next();
  console.log(value);
} while (!done);
