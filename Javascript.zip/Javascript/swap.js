var prev = 1,
  next = 2;

[prev, next] = [next, prev];
