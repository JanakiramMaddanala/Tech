const a = "RAM";
a[0] = a[2];

console.log(a);
