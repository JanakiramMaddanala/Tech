function RenderCount() {
  const [foo, setFoo] = React.useState(false);
  const counter = React.useRef(1);

  useEffect(() => {
    counter.current++;
  }, [foo]);
  return (
    <div>
      <button onClick={() => setFoo((f) => !f)}>Toggle Click </button>
      <div> Count: {counter.current} </div>
    </div>
  );
}
