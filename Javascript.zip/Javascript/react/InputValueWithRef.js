const InputValue = () => {
  return (
    <div>
      <input type="text" />
      <button>Get Text</button>
      <div>
        <span>{text ? text : ""}</span>
      </div>
    </div>
  );
};
