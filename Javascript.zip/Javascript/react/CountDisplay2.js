export function CountDisplay() {
  const [count, setCount] = useState(0);

  const handleClick = () => {
    setCount(count + 1);
    setCount(count + 1);
    setCount(count + 1);
    setCount(count + 1);
    setCount(count + 1);
  };

  return (
    <div>
      <button onClick={handleClick}>Counter</button>
      <Count count={count} />
    </div>
  );
}

const Count = ({ count }) => {
  return <span>{count}</span>;
};

const Count = React.memo(({ count }) => {
  useEffect(() => {
    console.log(1);
  });
  return <span>{count}</span>;
});

export function CountDisplay() {
  const [count, setCount] = useState(0);

  const handleClick = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <button onClick={handleClick}>Counter</button>
      <Count count={count} />
    </div>
  );
}

const Count = ({ count }) => {
  return <span>{count}</span>;
};
