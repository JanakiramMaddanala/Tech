import { useContext } from "react";
import { useDispatch, useSelector } from "react-redux";

function Counter() {
  const count = useSelector((state) => state.count);
  const dispatch = useDispatch();
  const context = useContext();

  const triggerCount = (type) => () => {
    dispatch({
      type
    });
  };

  return (
    <>
      {count || ""}
      <button onClick={triggerCount("increment")}>Increment</button>
      <button onClick={triggerCount("decrement")}>Decrement</button>
    </>
  );
}

export default Counter;


import { createStore } from "redux";

const initialState = {
  count: 0
};

const reducer = (state = initialState, action) => {
  if (action.type === "increment") {
    return { ...state, count: state.count + 1 };
  } else if (action.type === "decrement") {
    return { ...state, count: state.count - 1 };
  } else {
    return state;
  }
};

const store = createStore(reducer);

export default store;
