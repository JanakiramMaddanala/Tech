import React, { Component } from "react";

export default class Greeting extends Component {
  state = { count: 0 };

  handleClick() {
    this.setState({ count: this.state.count + 1 });
  }

  render() {
    return (
      <div>
        <GreetCounter handleClick={handleClick} />
        <div>Greeting was clicked {this.state.count}</div>
      </div>
    );
  }
}

const GreetCounter = (props) => {
  return <button onClick={props.handleClick}>Greeting</button>;
};
