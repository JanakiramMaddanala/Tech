export function CountDisplay() {
  const [count, setCount] = useState(0);

  const handleClick = () => {
    setCount(count + 1);
    setCount(count + 1);
    setCount(count + 1);
    setCount(count + 1);
    setCount(count + 1);
  };

  return (
    <div>
      <button onClick={handleClick}>Counter</button>
      <span>{count}</span>
    </div>
  );
}
