function* numbers() {
  yield 1;
  yield 2;
  yield 4;
  return 3;
}

for (const value of numbers()) {
  console.log(value);
}

// forof vs forin
const gen = numbers();
console.log(gen.next());
console.log(gen.next());
console.log(gen.next());
console.log(gen.next());

console.log(null == undefined);
