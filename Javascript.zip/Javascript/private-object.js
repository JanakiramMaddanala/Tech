const userName = Symbol("username");
const password = Symbol("password");

console.log(userName, password);

const user = {
  [userName]: "Foo",
  [password]: "bar",
  age: 25,
};

console.log(user[userName]);
console.log(user[userName]);
