// Implement queue using array
