const promise2 = new Promise((resolve, reject) => {
  setTimeout(() => reject("Promise Failed"), 1000);
});

const promise1 = new Promise((resolve, reject) => {
  setTimeout(() => resolve(10), 1000);
});

const promise3 = new Promise((resolve, reject) => {
  setTimeout(() => resolve(12), 5000);
});

promise1
  .then((res) => {
    console.log(res);
    throw Error("Error from promise1");
  })
  .then(
    (res) => console.log(res),
    (reason) => console.log(reason)
  )
  .catch((reason) => "Catch: " + reason);

Promise.all([promise1, promise2])
  .then((values) => console.log(values))
  .catch((error) => console.log(`I am ${error}`));

Promise.all([promise1, promise3])
  .then((values) => console.log(values))
  .catch((error) => console.log(error));

Promise.race([promise1, promise3])
  .then((values) => console.log("race: " + values))
  .catch((error) => console.log(error));

Promise.race([promise2, promise1, promise3])
  .then((values) => console.log("race: " + values))
  .catch((error) => console.log(error));
