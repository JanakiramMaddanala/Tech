// SET 1
// console.log(age)

// const age;

// console.log(getAge())

// age = 1;

// console.log(getAge())

// if(age >= 1) {
//     const age;
//     age = 28;
//     console.log(getAge())
// }

// console.log(getAge())

// function getAge() {
//     return age;
// }

// SET 2
// const colors = [];
// colors = ['red']

// SET 3
const vehicle = { type: "car", color: "blue" };

vehicle.type = "bike";

const array = [1, 2, 3, 5, 6];
const swaps = Math.floor(array.length / 2);
for (let i = 0, j = array.length - 1; i < swaps; i++, j--) {
  const temp = array[i];
  array[i] = array[j];
  array[j] = temp;
}

console.log(array);

const objects = [
  { id: 2, name: "a" },
  { id: 13, name: "a" },
  { id: 21, name: "a" },
  { id: 1, name: "a" },
];

console.log(objects.sort((a, b) => a.id - b.id));

function makeIterator(array) {
  let nextIndex = 0;
  return {
    next: function () {
      return nextIndex < array.length
        ? {
            value: array[nextIndex++],
            done: false,
          }
        : {
            done: true,
          };
    },
  };
}

// driver code
let it = makeIterator(["yo", "ya"]);
it.next().value; // 'yo' { value: 1, done: false}
it.next().value; // 'ya' { value: 2, done: false}
it.next().done; // true  { done: true }
