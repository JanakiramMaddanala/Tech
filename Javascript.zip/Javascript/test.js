const promise1 = new Promise((resolve, reject) => {
  setTimeout(() => resolve(10), 1000);
});

promise1
  .then((res) => {
    console.log(res);
    throw Error("Error from promise1");
  })
  .then(
    (res) => console.log(res),
    (reason) => console.log(reason)
  )
  .catch((reason) => "Catch: " + reason);
