const objects = [
  { id: 2, name: "a" },
  { id: 13, name: "a" },
  { id: 21, name: "a" },
  { id: 1, name: "a" },
];

console.log(objects.sort((a, b) => a.id - b.id));
