// Implement Queue using array

class Queue {
  enqueue(value) {}

  dequeue() {}

  front() {}

  isEmpty() {}
}

// Max number in an array
// [100, 180, 260, 310, 40, 535, 695, 80]

// Binary Searh Tree
// [1,3,4,10,50,100,120,125]

// From a unsorted array, check whether there are any two numbers that will sum up to a given number.
// [100, 180, 260, 310, 40, 535, 695, 80]
function sumFinder(arr, sum) {
  var len = arr.length;

  for (var i = 0; i < len - 1; i++) {
    for (var j = i + 1; j < len; j++) {
      if (arr[i] + arr[j] == sum) return true;
    }
  }
  return false;
}
