// Queue data structure
// No idea on classes or object literals. Unable to write simple ds code.

// Object readonly prop
// let employee = {
//     userId :
// };

// object.freeze(employee)

// hoisting
// showLanguage();  Undefined

// language = "English";

// showLanguage(); Undefined

// var language = "Spanish";

// var language;

// showLanguage(); Undefined

// function showLanguage() {
//   console.log(language);
// }

// language = "Hindi";

// getLanguage(); Undefined

// var language;

// var getLanguage = () => {
//   console.log(language);
// };

// getLanguage(); Undefined

// const numbers = [1, 11, 5, 10];

// console.log(numbers.sort());

// 1 5 10 11

// Async
// console.log(1);

// setTimeout(() => console.log(7), 1000);

// setTimeout(() => console.log(6));

// console.log(0);

// Promise.resolve(9).then(console.log);

// console.log(3);

// setTimeout(() => console.log(2));

// 1
// 0
// 3
// 9
// 6
// 2
// 7

// scope related
// const person = {
//     id: 1,
//     name: "Foo",
//     getName: function () {
//       return this.name;
//     },
//     getId: () => this.id,
//     getId2: function () {
//       const getId = () => this.id;
//       return getId();
//     },
//   };

//   console.log(person.getId()); Window Object
//   console.log(person.getName()); Foo
//   console.log(person.getId2()); Window Object
//   console.log(person.getName.call({})); Foo

// makeIterator

// let it = makeIterator([1, 2, 3]);
// it.next(); // { value: 1, done: false}
// it.next(); // { value: 2, done: false}
// it.next(); // { value: 3, done: false}
// it.next(); // { done: true }

// const makeIterator = (el) => {
//   el.map((item)=>
//   if(indexOf(item) == -1){
//     console.log("true")
//   } else{
//     console.log("false")
//   }
//    )
// }

// destructuring
// const address = {
//     city: { name: "HYD", pincode: { value: 500081 } },
// };

// const {value} =
