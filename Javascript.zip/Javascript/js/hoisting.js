showLanguage();

language = "English";

showLanguage();

var language = "Spanish";

var language;

showLanguage();

function showLanguage() {
  console.log(language);
}

language = "Hindi";

getLanguage();

var language;

var getLanguage = () => {
  console.log(language);
};

getLanguage();
