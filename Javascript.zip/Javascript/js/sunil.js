// no idea on ds

// showLanguage();//undefined

// language = "English";

// showLanguage();//English

// var language = "Spanish";

// var language;

// showLanguage();//Spanish

// function showLanguage() {
//   console.log(language);
// }

// language = "Hindi";

// getLanguage();//Hindi

// var language;

// var getLanguage = () => {
//   console.log(language);
// };

// getLanguage();//Hindi

// Async

// console.log(1);//1

// setTimeout(() => console.log(7), 1000);//6

// setTimeout(() => console.log(6));//4

// console.log(0);//2

// Promise.resolve(9).then(console.log);//7

// console.log(3);//3

// setTimeout(() => console.log(2));//5

// Readonly prop
// let employee = {};
// employee.userID = "1";

// for (var index = 0; index < 5; index++) {
//     setTimeout(() => {
//       console.log(index);
//     });
//   }

// 0 to 4

// no idea of reduce implementation and didn't try to solve

// const person = {
//     id: 1,
//     name: "Foo",
//     getName: function () {
//       return this.name;
//     },
//     getId: () => this.id,
//     getId2: function () {
//       const getId = () => this.id;
//       return getId();
//     },
//   };

//   console.log(person.getId());//function
//   console.log(person.getName());//foo
//   console.log(person.getId2());//1

//   const getName = person.getName;
//   console.log(getName());//foo
//   console.log(getName.call(person));//foo
//   console.log(person.getId.call(person));//1
//   console.log(person.getId2.call(person));//1

// const address = {
//     city: { name: "HYD", pincode: { value: 500081 } },
//   };

//   let a={
//     ...address,
//   ...address:{
//     pincode
//   }
//   }

// const numbers = [1, 11, 5, 10];

// console.log(numbers.sort());

// let it = makeIterator([1, 2, 3]);
// it.next(); // { value: 1, done: false}
// it.next(); // { value: 2, done: false}
// it.next(); // { value: 3, done: false}
// it.next(); // { done: true }

// const array = [1, 2, 3, 5, 6];
// for(var i=array.length;i<array.length;i--){
// let a=array[i].pop();
// array.unshift(a);
// }

// const promise = new Promise((resolve, reject) => {
//     setTimeout(() => resolve(10), 1000);
//   });

//   promise
//     .then((res) => {
//       console.log(res);//10
//       throw Error("Error from promise");
//     })
//     .then(
//       (res) => console.log(res),//10
//       (reason) => console.log(reason)//10
//     )
//     .catch((reason) => "Catch: " + reason);

// push(value) --> push
// pop
// peek
// print

// const stack = new Stack();

// stack.push(1)
// stack.push(10)
// stack.push(100)
// statck.pop() ==> 100
// let stack = [];

// const pushData = (a) => {
//   stack.push(a);
//   console.log(stack);
// };
// const popData = () => {
//   stack.pop();
// };
// pushData(1);

// pushData(10);
// console.log(stack);
// pushData(100);
// console.log(stack);

// // popData();
// // console.log(stack);
// // popData()
// // console.log(stack);
// // popData()
// // console.log(stack);
