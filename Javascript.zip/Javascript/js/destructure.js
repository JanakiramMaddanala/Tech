// Extract developers through destructuring
const projectMembers = ["Mary", "John", "DEV1", "DEV2", "DEV3"];

// Extract pincode value
const address = {
  city: { name: "HYD", pincode: { value: 500081 } },
};
