// Add readonly property on a object

let employee = {};

// userId property to this object and it should be readonly
