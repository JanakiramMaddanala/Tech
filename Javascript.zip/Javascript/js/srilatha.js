// for (var index = 0; index < 5; index++) {
//     setTimeout(() => {
//       console.log(index);
//     });
//   }
// 5 printed 5 times

showLanguage(); //English

language = "English";

showLanguage(); //spanish

var language = "Spanish";

var language;

showLanguage(); //Hindi

function showLanguage() {
  console.log(language);
}

language = "Hindi";

getLanguage();

var language;

var getLanguage = () => {
  console.log(language);
};

getLanguage(); // undefined

const numbers = [1, 11, 5, 10];

console.log(numbers.sort());
1, 5, 10, 11;

const person = {
  id: 1,
  name: "Foo",
  getName: function () {
    return this.name;
  },
  getId: () => this.id,
  getId2: function () {
    const getId = () => this.id;
    return getId();
  },
};

console.log(person.getId()); //window O
console.log(person.getName()); //Foo
console.log(person.getId2());

const address = {
  city: { name: "HYD", pincode: { value: 500081 } },
};

const { name: sample, pincode: sample2 } = address;

console.log(sample2);

// function a(input) {
//     let value = 1;

//     function b() {
//       let value = 3;
//       return c;
//     }

//     function c() {
//       return value + input;
//     }

//     return b;
//   }

//   console.log(a(10)()()); //31
