const number = 100;
const string = "Hi";

let obj1 = {
  value: "a",
};

let obj2 = {
  value: "b",
};

let obj3 = obj2;

function change(number, string, obj1, obj2) {
  number = number * 10;
  string = "Hello";
  obj1 = obj2;
  obj2.value = "c";
}

change(number, string, obj1, obj2);

console.log(number);
console.log(string);
console.log(obj1.value);


const address = {
  city: { name: "HYD", pincode: { value: 500081 } },
};

const {print} = {address.value}