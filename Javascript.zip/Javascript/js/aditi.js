import "./styles.css";
import React from "react";

export default function App() {
  return <div>Welcome</div>;
}

// let queueArray = [];
// class Queue {
//   constructor(value) {
//     this.value = value;
//   }


//   enqueue() {
//     queueArray.push(this.value);
//     return queueArray;
//   }
//   dequeue() {
//     queueArray.shift()
//     return queueArray;
//   }
// }

// let que = new Queue(8);
// console.log(que.enqueue());
// console.log(que.enqueue());
// console.log(que.dequeue())

let it = makeIterator([1, 2, 3]);

it.next(); // { value: 1, done: false}
it.next(); // { value: 2, done: false}
it.next(); // { value: 3, done: false}
it.next(); // { done: true }


function makeIterator(arr) {
    let obj = {};
    for(let i = 0; i < arr.length; i++) {
      if(arr[i].length > 0) {
        let poppedEle = arr.pop();
        return obj ={ value: poppedEle, done: false };
      } else {
        return obj = {done: true};
      }
    }
}
function x = (a) => 
it.next(); // { value: 1, done: false}
it.next(); // { value: 2, done: false}
it.next(); // { value: 3, done: false}
it.next(); // { done: true }

const person = {
    id: 1,
    name: "Foo",
    getName: function () {
      return this.name;
    },
    getId: () => this.id,
    getId2: function () {
      const getId = () => this.id;
      return getId();
    },
  };
  
  console.log(person.getId()); //1
  console.log(person.getName()); //Foo
  console.log(person.getId2()); //undefined
  
  console.log(person.getName.call({ name: "Foo New", salary: 1 })); //Foo New 
  
  
  for (var index = 0; index < 5; index++) {
    setTimeout(() => {
      console.log(index);
    });
  }

  // Extract pincode value
const address = {
    city: { name: "HYD", pincode: { value: 500081 } },
  };
  
  console.log(address.city.pincode.value);

  console.log(1);

setTimeout(() => console.log(7), 1000);

setTimeout(() => console.log(6));

console.log(0);

Promise.resolve(9).then(console.log);

console.log(3);

setTimeout(() => console.log(2));

// 1, 0, 3, 9, 6, 2, 7 

const numbers = [1, 11, 5, 10];

console.log(numbers.sort());

numbers.localCompare();

function compare() { return }