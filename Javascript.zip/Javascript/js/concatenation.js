console.log(a ? "Valid" : "Invalid");
