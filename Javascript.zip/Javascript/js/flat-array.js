const fruits = [
  [["apple"]],
  "mango",
  ["kiwi"],
  [[[["orange"]]], ["guava"]],
  "watermelon",
];

const fruits = ["apple", "mango", "kiwi", "orange", "guava", "watermelon"];
