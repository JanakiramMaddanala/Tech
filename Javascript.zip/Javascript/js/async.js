console.log(1);

setTimeout(() => console.log(7), 1000);

setTimeout(() => console.log(6));

console.log(0);

Promise.resolve(9).then(console.log);

console.log(3);

setTimeout(() => console.log(2));

const number = 100;
const string = "Hi";

let obj1 = {
  value: "a",
};

let obj2 = {
  value: "b",
};

let obj3 = obj2;

function change(number, string, obj1, obj2) {
  number = number * 10;
  string = "Hello";
  obj1 = obj2;
  obj2.value = "c";
}

change(number, string, obj1, obj2);

console.log(number);
100;
console.log(string);

console.log(obj1.value);
console.log(obj2.value);
