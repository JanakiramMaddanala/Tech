showLanguage(); // undefined

language = "English";

showLanguage(); //English

var language = "Spanish";

var language;

showLanguage(); //undefined

function showLanguage() {
  console.log(language);
}

language = "Hindi";

getLanguage(); // Hindi

var language;

var getLanguage = () => {
  console.log(language);
};

getLanguage(); //undefined

...........


console.log(1);

setTimeout(() => console.log(7), 1000);

setTimeout(() => console.log(6));

console.log(0);

Promise.resolve(9).then(console.log(9));

console.log(3);

setTimeout(() => console.log(2));


// 1, 0, 3, 6, 2, 9, 7

for (var index = 0; index < 5; index++) {
    setTimeout(() => {
      console.log(index);
    });
  }
  
  
  //6

  const address = {
    city: { name: "HYD", pincode: { value: 500081 } },
  };
  
  {city} = address
  

  const numbers = [1, 11, 5, 10];

  console.log(numbers.sort());
  console.log(numbers.sort()=> a < b );
  

  
let count = 0;

function makeIterator(arr){
count= count+1;
 const next = function(){
  if(arr.length > count){
    return  { value: arr[count], done: false}
  }else{
    return  { done: true}
  }
}
}
let it = makeIterator([1,2,3]);
it.next();

// class Queue {
//   arr = [];
//   constructor(){

//   }
//   function enqueue(item){
//     arr.push(item);
//   }

//   function dequeue(item){
//     arr.shift()
//   }

//   function print(item){
//     console.log(arr);
//   }
// }

// let firstQueue = new Queue();
// firstQueue.enqueue(1);
// firstQueue.enqueue(2);
// firstQueue.enqueue(3);
// firstQueue.print();
// firstQueue.dequeue(1);
// firstQueue.print();
