const array = [1, 2, 3, 5, 6];
const swaps = Math.floor(array.length / 2);
for (let i = 0, j = array.length - 1; i < swaps; i++, j--) {
  const temp = array[i];
  array[i] = array[j];
  array[j] = temp;
}

console.log(array);
