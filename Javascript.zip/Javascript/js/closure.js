function Greet(message) {
  this.value = ", ";
  return function (name) {
    return message + this.value + name;
  };
}

console.log(Greet("Hello")("Foo"));

function a(input) {
  let value = 1;

  function b() {
    let value = 3;
    return c;
  }

  function c() {
    return value + input;
  }

  return b;
}

console.log(a(10)()());
