showLanguage();

language = "English";

showLanguage();

var language = "Spanish";

var language;

showLanguage();

function showLanguage() {
  console.log(language);
}

// undefined
// English
// spanish

language = "Hindi";

getLanguage();

var language;

var getLanguage = () => {
  console.log(language);
};

getLanguage();

// undefined
// Hindi

console.log(1);

// as setTimeout(() => console.log(7), 1000);

// as setTimeout(() => console.log(6));

console.log(0);

// as Promise.resolve(9).then(console.log(9));

console.log(3);

// as setTimeout(() => console.log(2));

// 1
// 0
// 3
// 9
// 6
// 2
// 7

for (let index = 0; index < 5; index++) {
  setTimeout(() => {
    console.log(index);
  }, index * 1000);
}

// 0
// after 1 sec 1 will print
// after 2 sec 2 will print
// after 3 sec 3 will print

for (var index = 0; index < 5; index++) {
  setTimeout(() => {
    console.log(index);
  });
}

// 0
// 1
// 3
// 4

const objects = [
  { id: 2, name: "a" },
  { id: 13, name: "b" },
  { id: 21, name: "c" },
  { id: 1, name: "d" },
];

objects.sort((a, b) => {
  return a.id - b.id;
});

[1, 2, 3].reduce((prev, acc) => {
  return;
});

function reducer() {}

reducer([1, 2, 3]);

let person = {};

object.defineProperty(person, "name", {
  value: "ramesh",
  writable: false,
});

person.salary = 2000;

for (var key in person) {
  console.log(key);
}

let it = makeIterator([1, 2, 3]);
it.next(); // { value: 1, done: false}
it.next(); // { value: 2, done: false}
it.next(); // { value: 3, done: false}
it.next(); // { done: true }

function makeIterator(arr) {
  function next() {}
}

const number = 100;
const string = "Hi";

let obj1 = {
  value: "a",
};

let obj2 = {
  value: "b",
};

let obj3 = obj2;

function change(number, string, obj1, obj2) {
  number = number * 10;
  string = "Hello";
  obj1 = obj2;
  obj2.value = "c";
}

change(number, string, obj1, obj2);

console.log(number); // throws an error
console.log(string); //
console.log(obj1.value);

const person = {
  id: 1,
  name: "Foo",
  getName: function () {
    return this.name;
  },
  getId: () => this.id,
  getId2: function () {
    const getId = () => this.id;
    return getId();
  },
};

console.log(person.getId()); // window or undefined
console.log(person.getName()); // foo
console.log(person.getId2()); // 1

console.log(person.getId.call(person)); // call apply bind

console.log("1" == 1); // true
console.log("1" === 1); // false
console.log("" == ![]); // false or undefined
console.log("" == []); // false
console.log("1" == { name: "ram", toString: () => "1" }); // false

const promise = new Promise((resolve, reject) => {
  setTimeout(() => resolve(10), 1000);
});

promise
  .then((res) => {
    console.log(res);
    throw Error("Error from promise");
  })
  .then(
    (res) => console.log(res),
    (reason) => console.log(reason)
  )
  .catch((reason) => console.log("Catch: " + reason));

// 10
// Catch: Error from promise

function a(input) {
  let value = 1;

  function b() {
    let value = 3;
    return c;
  }

  function c() {
    return value + input;
  }

  return b;
}

console.log(a(10)()());

// undefined
// 11

const numbers = [1, 3, 4, 10, 50, 100, 120, 125];

// find 10

function binarySearch(numbers) {
  const len = numbers.length / 2;
}

binarySearch(numbers);
