//Implement reduce method
Array.prototype.reduce = function (fn, initialValue) {
  console.log(this);
  let accumulator = initialValue;
  Array.from(this).forEach((item) => {
    accumulator = fn(accumulator, item);
  });

  return accumulator;
};
