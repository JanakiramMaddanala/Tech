const person = {
  id: 1,
  name: "Foo",
  getName: function () {
    return this.name;
  },
  getId: () => this.id,
  getId2: function () {
    const getId = () => this.id;
    return getId();
  },
};

console.log(person.getId());
console.log(person.getName());
console.log(person.getId2());
console.log(person.getName.call({}));
const getName = person.getName;
console.log(getName());
console.log(getName.call(person));
console.log(person.getId.call(person));
console.log(person.getId2.call(person));

var obj = { name: "bar" };
const getName1 = getName.bind(obj);
obj = person;
console.log(getName1());
