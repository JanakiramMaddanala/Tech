const promise = new Promise((resolve, reject) => {
  setTimeout(() => resolve(10), 1000);
});

promise
  .then((res) => {
    console.log(res);
    throw Error("Error from promise");
  })
  .then(
    (res) => console.log(res),
    (reason) => console.log(reason)
  )
  .catch((reason) => "Catch: " + reason);
