let age;

console.log(getAge());

age = 1;

console.log(getAge());

if (age >= 1) {
  let age;
  age = 28;
  console.log(getAge());
}

console.log(getAge());

function getAge() {
  return age;
}
