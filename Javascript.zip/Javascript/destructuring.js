const address = {
  country: {
    name: "IND",
    state: { name: "TS", city: { name: "HYD", pincode: { value: 500081 } } },
  },
};

// const address = {
//   city: { name: "HYD", pincode: { value: 500081 } },
// };

const {
  country: {
    state: {
      city: {
        pincode: { value: pin },
      },
    },
  },
} = address;

console.log(pin);
