console.log("1" == 1);
console.log("1" === 1);
console.log("1" == ![]);
console.log("1" == []);
console.log("1" == { name: "ram", toString: () => "1" });
console.log("1" === { name: "ram", toString: () => "1" });

console.log("1" == 1);
console.log("1" === 1);
console.log(1 == ![]);
console.log("1" == []);
console.log("1" == { name: "ram", toString: () => "1" });
