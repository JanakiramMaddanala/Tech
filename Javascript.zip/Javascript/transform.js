const employees = [
  {
    id: 1,
    name: "Jacob",
    city: "Hyd",
    designation: "Software Engineer",
  },
  {
    id: 2,
    name: "Riya",
    city: "Bangalore",
    designation: "HR Manager",
  },
];

const employeesById = {
  1: { name: "Jacob", city: "Hyd", designation: "Software Engineer" },
  2: { name: "Riya", city: "Bangalore", designation: "HR Manager" },
};
