function areEqual(obj1, obj2) {}
